package com.company;

import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {

        Star sun = new Star("Sun", 695342,1.9885E30,5777);

        PlanetSystem solarSystem = new PlanetSystem("Solar System", sun);

        solarSystem.addPlanet(new Planet("Mercury", 3.283E23, 2439.7, 0.387, 0.206, 88, sun ));
        solarSystem.addPlanet(new Planet("Venus", 4.867E24, 6051.8,0.723, 0.007, 225, sun));
        solarSystem.addPlanet(new Planet("Earth", 5.972E24, 6371,1, 0.017, 365, sun));
        solarSystem.addPlanet(new Planet("Mars", 6.39E23, 3389.5,1.524, 0.093, 687, sun));
        solarSystem.addPlanet(new Planet("Jupiter", 1.898E27, 71492,5.20440, 0.049, 4380, sun));
        solarSystem.addPlanet(new Planet("Saturn", 5.683E26, 58232,9.5826, 0.057, 10585, sun));
        solarSystem.addPlanet(new Planet("Uranus", 8.681E25, 25362,19.2184, 0.046, 30660, sun));
        solarSystem.addPlanet(new Planet("Neptune", 1.024E26, 24622,30.11, 0.010, 60225, sun));

        System.out.println(solarSystem);

        Planet mercury = solarSystem.getPlanets().get(0);
        Planet venus = solarSystem.getPlanets().get(1);
        Planet earth = solarSystem.getPlanets().get(2);
        Planet mars = solarSystem.getPlanets().get(3);
        Planet jupiter = solarSystem.getPlanets().get(4);
        Planet saturn = solarSystem.getPlanets().get(5);
        Planet uranus = solarSystem.getPlanets().get(5);
        Planet neptune = solarSystem.getPlanets().get(7);

        System.out.println("First Planet: " + mercury);
        System.out.println("Third Planet: " + earth);



        System.out.println("=========================================================================================");
        System.out.println("                                      Oppgave 2.4                                      ");

        System.out.println("Mjup og Rjup for planet");
        System.out.println("Saturn sin masse i Mjup er: " + saturn.beregnMjup());
        System.out.println("Saturn sin radius i Rjup er: " + saturn.beregnRjup());

        System.out.println(" ");

        System.out.println("Msun og Rsun for sun");
        System.out.println("Sun sin masse i Msun er: " + sun.beregnMsun());
        System.out.println("Sun sin radius i Rsun er: " + sun.beregnRsun());

        System.out.println("=========================================================================================");
        System.out.println("                                      Oppgave 2.5                                      ");

        System.out.println("Neptune sin surface gravity er: " + neptune.beregnGravitasjon());

        System.out.println("=========================================================================================");
        System.out.println("                                      Oppgave 2.6                                      ");

        Planet smallestPlanet = solarSystem.getSmallestPlanet();
        Planet largestPlanet = solarSystem.getLargestPlanet();

        System.out.println(smallestPlanet.getName() + " is the smallest planet in the " + solarSystem.getName());
        System.out.println(largestPlanet.getName() + " is the largest planet in the " + solarSystem.getName());

        System.out.println("=========================================================================================");
        System.out.println("                                      OBLIG 3                                      ");

        System.out.println("=========================================================================================");
        System.out.println("                                      Oppgave 2.2                                      ");

        Planet hentUtPlanet = solarSystem.hentPlanet();
        System.out.println(hentUtPlanet);

        System.out.println("=========================================================================================");
        System.out.println("                                      Oppgave 2.4 b                                      ");

        System.out.println(hentUtPlanet.getName());
    }

}