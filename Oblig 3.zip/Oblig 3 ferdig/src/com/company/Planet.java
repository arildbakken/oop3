package com.company;

public class Planet extends NaturalSatellite{
    private static final double mjup = 1.898E27;
    private static final int rjup = 71492;
    private static double gk = 0.00000000006674;

    public Planet(String name, double radius, double mass, double semiMajorAxis, double eccentricity, double orbitalPeriod, Star centralCelestialBody) {
        super(name, radius, mass, semiMajorAxis, eccentricity, orbitalPeriod, centralCelestialBody);
    }

    public double beregnMjup(){
        return mjup / getMass();
    }

    public double beregnRjup(){
        return getRadius() / rjup;
    }

    public double beregnGravitasjon(){
        return gk * getMass() / (getRadius() * getRadius());
    }



    @Override
    public String toString() {
        return "Name: " + getName() + '\n' +
                "Radius: " + getRadius() + " km" + '\n' +
                "Mass: " + getMass() + " kg" + '\n' +
                "Semi Major Axis: " + getSemiMajorAxis()  + '\n' +
                "Eccentricity: " + getEccentricity() + '\n' +
                "Orbital Period: " + getOrbitalPeriod() + " dager" + '\n' +
                "Orbits: " + getCentralCelestialBody().getName() ;
    }
}
