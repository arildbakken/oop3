package com.company;

public class Star extends CelestialBody{
    private double effectivetemp;
    private static final double msun = 1.98892E30;
    private static final double rsun = 695700;

    public Star(String name, double radius, double mass, double effectivetemp) {
        super(name, radius, mass);
        this.effectivetemp = effectivetemp;
    }

    public double getEffectivetemp() {
        return effectivetemp;
    }

    public void setEffectivetemp(double effectivetemp) {
        this.effectivetemp = effectivetemp;
    }

    public double beregnMsun(){
        return msun / getMass();
    }

    public double beregnRsun(){
        return getRadius() / rsun;
    }

    @Override
    public String toString() {
        return '\n' + "Name: " + getName() + '\n' +
                "Radius: " + getRadius() + " km" + '\n' +
                "Mass: " + getMass() + " kg" + '\n' +
                "Effectivetemp: " + effectivetemp + " °C" + '\n';
    }
}